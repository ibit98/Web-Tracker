Web Controller 1.0
An Web Extension to View & Control Web Activity (Remote & Locally)

Developed by Indranil Bit

Steps to implement the Application

# Download or Clone the Repository and then Extract

# Open Web Browser

# Enable Developer Mode

# Click on Load Extension

# Select 'ext' folder inside the repository

# Load the extension

# Click on the Extension icon in your Browser

# Follow prompted instructions

# And the you are good to go !
